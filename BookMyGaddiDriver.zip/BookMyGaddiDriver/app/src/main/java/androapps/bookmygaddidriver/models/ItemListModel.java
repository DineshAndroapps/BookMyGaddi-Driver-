package androapps.bookmygaddidriver.models;

/**
 * Created by androapps on 2/13/17.
 */
public class ItemListModel {
    public String sourcelat;
    public String sourcelog;
    public String destinationlat;
    public String destinationlog;
    public String booking_date;
    public String drivername;
    public String vehicle_type;
    public String sourcepoint;
    public String destinationpoint;
    public String distance;
    public String traveltime;
    public String fare;
    public String ridetype;
    public String ridebill;
    public String discountamount;
    public String total_fare;
    public String offer_code;
    public String taxname1;
    public String taxname2;
    public String taxname3;
    public String taxamount1;
    public String taxamount2;
    public String taxamount3;
    public String roundof;
}

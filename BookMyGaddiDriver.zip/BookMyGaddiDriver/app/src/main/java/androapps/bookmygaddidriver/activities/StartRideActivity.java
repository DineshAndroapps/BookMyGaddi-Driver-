package androapps.bookmygaddidriver.activities;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

import androapps.bookmygaddidriver.R;

public class StartRideActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start_ride);
    }
}
